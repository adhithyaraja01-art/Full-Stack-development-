const form = document.getElementById('contact-form');
const status = document.getElementById('form-status');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const button = form.querySelector('button');
  const data = {
    name: form.name.value.trim(),
    email: form.email.value.trim(),
    message: form.message.value.trim(),
  };

  button.disabled = true;
  status.textContent = 'sending…';
  status.dataset.state = '';

  try {
    const res = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    const result = await res.json();

    if (res.ok) {
      status.textContent = 'message sent — thanks, I\'ll reply by email.';
      status.dataset.state = 'ok';
      form.reset();
    } else {
      status.textContent = result.error || 'something went wrong — try again.';
      status.dataset.state = 'err';
    }
  } catch (err) {
    status.textContent = 'could not reach the server — try again shortly.';
    status.dataset.state = 'err';
  } finally {
    button.disabled = false;
  }
});
