// server.js
// Minimal Express backend: serves the static portfolio and stores
// contact-form submissions to a local JSON file.
//
// To send real emails instead of just storing submissions, install
// nodemailer (`npm install nodemailer`) and fill in the marked section
// in the /api/contact route below.

const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'contact-submissions.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function readSubmissions() {
  if (!fs.existsSync(DATA_FILE)) return [];
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveSubmission(entry) {
  const all = readSubmissions();
  all.push(entry);
  fs.writeFileSync(DATA_FILE, JSON.stringify(all, null, 2));
}

app.post('/api/contact', (req, res) => {
  const { name, email, message } = req.body || {};

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'name, email and message are all required.' });
  }
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    return res.status(400).json({ error: 'that email address doesn\'t look valid.' });
  }

  const entry = {
    name: String(name).slice(0, 200),
    email: String(email).slice(0, 200),
    message: String(message).slice(0, 5000),
    receivedAt: new Date().toISOString(),
  };

  try {
    saveSubmission(entry);
    console.log('New contact submission:', entry);

    // --- Optional: send yourself an email instead of / in addition to
    // storing locally. Requires `npm install nodemailer` and environment
    // variables for your mail provider.
    //
    // const nodemailer = require('nodemailer');
    // const transporter = nodemailer.createTransport({
    //   service: 'gmail',
    //   auth: { user: process.env.MAIL_USER, pass: process.env.MAIL_PASS },
    // });
    // await transporter.sendMail({
    //   from: process.env.MAIL_USER,
    //   to: process.env.MAIL_USER,
    //   subject: `Portfolio message from ${entry.name}`,
    //   text: `${entry.message}\n\nReply to: ${entry.email}`,
    // });

    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('Failed to save submission:', err);
    return res.status(500).json({ error: 'could not save your message — please try again.' });
  }
});

// Simple endpoint to review stored submissions locally (not linked from the UI).
app.get('/api/contact', (req, res) => {
  res.json(readSubmissions());
});

app.listen(PORT, () => {
  console.log(`Portfolio running at http://localhost:${PORT}`);
});
