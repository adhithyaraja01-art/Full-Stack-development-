# Adhithiyan A. — Portfolio

A full-stack personal portfolio: a static front end (HTML/CSS/JS) served by
a small Node/Express backend that also handles the contact form.

## Run it locally

```bash
npm install
npm start
```

Then open http://localhost:3000

## What's inside

```
portfolio/
├── public/
│   ├── index.html      the whole page (hero, work, about, skills, contact)
│   ├── css/style.css   all styling
│   └── js/main.js      contact form submission logic
├── server.js           Express server + /api/contact endpoint
├── package.json
└── contact-submissions.json   created automatically the first time
                               someone submits the contact form
```

## Before you submit this for Thiranex

Search the project for the word **replace** — every spot marked with it is
placeholder content you should swap for the real thing:

1. **Projects** (`public/index.html`, `#work` section) — swap in your actual
   projects: title, one or two sentences on what it does and what result it
   had, the real tech stack, and a real link (GitHub repo or live demo).
2. **About paragraph** (`#about`) — two or three specific sentences about
   you, written for a recruiter skimming quickly.
3. **Skills** (`#skills`) — only list what you can talk about in an
   interview.
4. **Contact links** — your email is already set to
   `310625104010@eec.srmrmp.edu.in`. Still replace the GitHub/LinkedIn
   placeholder URLs in `index.html` (contact section) with your real
   profiles.
5. **Page title & description** — update the `<title>` and `<meta
   description>` tags at the top of `index.html`.

## Making the contact form actually email you

Right now, submissions are validated and saved to
`contact-submissions.json` on the server, and logged to the console. To
also get an email:

```bash
npm install nodemailer
```

Then uncomment the nodemailer block in `server.js` inside the
`/api/contact` route, and set two environment variables before starting
the server:

```bash
MAIL_USER=youraddress@gmail.com MAIL_PASS=your-app-password npm start
```

(Use a Gmail **app password**, not your normal password — generate one
from your Google Account's security settings.)

## Deploying it

This needs a host that can run a Node server (not a static-only host):

- **Render** or **Railway** — easiest for a small Express app, free tiers
  available. Point it at this repo, build command `npm install`, start
  command `npm start`.
- **Vercel/Netlify** — possible but you'd need to convert `server.js` into
  a serverless function; simplest to use Render/Railway instead.

Push this folder to a GitHub repo first, then connect that repo in
whichever host you choose.
